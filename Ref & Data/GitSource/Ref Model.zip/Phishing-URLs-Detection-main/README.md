# Phishing-URLs-Detection
A machine learning script used for detecting phishing websites.
